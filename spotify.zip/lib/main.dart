import 'package:flutter/material.dart';
import 'package:spotify/src/pages/app.dart';

void main() {
  runApp(const MyApp());
}

