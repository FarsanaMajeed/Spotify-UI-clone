import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spotify/src/pages/home.dart';
import 'package:spotify/src/pages/homepage.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.white24,
        leading:IconButton(
        onPressed: (){},
        icon:Icon(Icons.arrow_back_sharp,size: 24,),
        ),

      title:Padding(
      padding:const EdgeInsets.only(left:54),

      child:Text('Settings',style: TextStyle(color: Colors.white,
        fontWeight: FontWeight.bold,fontSize:21 ,),
        textAlign: TextAlign.center,),
      ),
      ),
      body: ListView(
        children: [
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Free Account',style: TextStyle(color: Colors.white,
                  fontWeight: FontWeight.bold,fontSize: 20),textAlign: TextAlign.center,),
            ],
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
          Chip(
            padding: const EdgeInsets.only(left: 3.0),
            label: Text(
              'Go Premium',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 17,
                  fontWeight: FontWeight.bold),
            ),
            backgroundColor: Colors.white,
          ),
          Divider(
            thickness: 20,
            color: Colors.black,
          ),
          ListTile(
            leading: CircleAvatar(
              radius: 25,
              backgroundColor: Colors.pinkAccent,
              child: const Text(
                'J',
                style: TextStyle(color: Colors.black),
              ),
            ),
            title: Text('jan',style: TextStyle(color: Colors.white,fontSize: 22),),
            subtitle:  Text('View  profile',style: TextStyle(color: Colors.grey,),),
            trailing: Icon(Icons.arrow_forward_ios,color: Colors.white,size: 14,),
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(padding: EdgeInsets.only(left: 14),),
              Text('Data Saver',style: TextStyle(color: Colors.white,
                  fontWeight: FontWeight.bold,fontSize: 20),textAlign: TextAlign.start,),
            ],
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
          ListTile(
           onTap: () {},
            title:Text('Audio Quality',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Sets your audio quality to low and disables artist canvases.',
            style: TextStyle(color: Colors.grey,fontSize: 12),),
         ),

    Divider(
            thickness: 10,
            color: Colors.black,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(padding: EdgeInsets.only(left: 14),),
              Text('Video Podcasts',style: TextStyle(color: Colors.white,
                  fontWeight: FontWeight.bold,fontSize: 20),textAlign: TextAlign.start,),
            ],
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),

          ListTile(
            onTap: () {},
            title:Text('Download audio only',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Save videos podcasts as audio only',
              style: TextStyle(color: Colors.grey,fontSize: 12),),

          ),
          ListTile(
            onTap: () {},
            title:Text('Stream audio only',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Play video podcasts as audio only when not on wifi',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            subtitle: Text('Note:video is not streamed when the spotify app background',
              style: TextStyle(color: Colors.grey,fontSize: 12),
            ),
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(padding: EdgeInsets.only(left: 14),),
              Text('Playback',style: TextStyle(color: Colors.white,
                  fontWeight: FontWeight.bold,fontSize: 20),textAlign: TextAlign.start,),
            ],
          ),
          Divider(
            thickness: 10,
            color: Colors.black,
          ),
      ListTile(
        onTap: () {},
        title:Text('Crossfade',style:TextStyle(color:Colors.white,fontSize:18)),
        subtitle: Text('Allows you to crossfade between songs',
          style: TextStyle(color: Colors.white,fontSize: 12),),
      ),
          ListTile(
            onTap: () {},
            title:Text('Gapless',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Allows gapless playback',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            onTap: () {},
            title:Text('Automix',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Allows smooth transitions  between songs in a playlist',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            onTap: () {},
            title:Text('Allow Explicit Content',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Turn on to play explicit content ',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            onTap: () {},
            title:Text('Show unplayable songs',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Show songs that are unplayable',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            onTap: () {},
            title:Text('Normalize volume',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Set the same volume level for all tracks',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
          ListTile(
            onTap: () {},
            title:Text('Mono Audio',style:TextStyle(color:Colors.white,fontSize:18)),
            subtitle: Text('Makes the left and right speakers play the same audio',
              style: TextStyle(color: Colors.grey,fontSize: 12),),
          ),
        ],
      ),
    );
  }
}
